from primely import core, db_handler

def paycheck_analysis(param):
    """Handles every process of paycheck-graph package."""
    full_analyzer = core.FullAnalyzer()

    try:
        # top 
        full_analyzer.starting_msg()
        full_analyzer.process_all_input_data()
        
        # middle
        if param == 'object':
            file_based_visualizer = core.ObjectFileBasedVisualizer()
            file_based_visualizer.create_dataframe_in_time_series()
            paycheck_series = file_based_visualizer.get_packaged_paycheck_series()
            file_based_visualizer.export_in_jsonfile(paycheck_series)
        elif param == 'sqlite':
            db_handler.PaycheckDataInjector(memory=False)

        # bottom
        full_analyzer.ending_msg()
    except:
        return False
    else:
        return True
