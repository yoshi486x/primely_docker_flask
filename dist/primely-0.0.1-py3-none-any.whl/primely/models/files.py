
import json
import os
import pathlib

# from queueing.py
def extract_filenames(pdf_dir, suffix=False):
    """Extract filename without suffix"""

    if suffix:
        return os.listdir()

    for item in os.listdir(pdf_dir):
        filename, _ = os.path.splitext(item)
        all_files.append(filename)

    return sorted(all_files)

# from txt_converter.py, load_data
def load_data(filename, txt_dir):
    """Load data"""

    text_file_path = pathlib.Path(txt_dir, filename).with_suffix('.txt')

    with open(text_file_path, 'r') as text_file:
        list_data = text_file.read().splitlines()
    while '' in list_data:
        list_data.remove('')

    return list_data


# from visualizing.py
class JsonLoaderModel(object):
    def __init__(self, filename, dir_path, dict_data=None):
        self.dir_path = dir_path
        if not dict_data:
            dict_data = self._get_dict_data(filename)
        self.dict_data = dict_data

    def _get_dict_data(self, filename):
        file_path = pathlib.Path(self.dir_path, filename)
        with open(file_path, 'r') as json_file:
            return json.load(json_file)