import pandas as pd
import sqlite3


TABLES = {}
TABLES['employees'] = (
    "CREATE TABLE employees ("
    "emp_no DECIMAL(7) PRIMARY KEY, "
    "emp_name VARCHAR(255) NOT NULL, "
    "dept_name VARCHAR(255)"
    ");")

TABLES['categories'] = (
    "CREATE TABLE categories("
    "    cat_id INTEGER AUTO_INCREMENT PRIMARY KEY,"
    "    cat_name VARCHAR(255) NOT NULL,"
    "    genre_name VARCHAR(255) NOT NULL"
    ");")

TABLES['value_by_types'] = (
    "CREATE TABLE value_by_types("
    "    id INTEGER AUTO_INCREMENT PRIMARY KEY,"
    "    emp_no DECIMAL(7) NOT NULL,"
    "    paid_date DATE NOT NULL,"
    "    cat_name VARCHAR(255) NOT NULL,"
    "    cat_type VARCHAR(255) NOT NULL,"
    "    value_int INTEGER,"
    "    value_flt FLOAT,"
    "    value_str STRING,"
    "    UNIQUE(emp_no, paid_date, cat_name),"
    "    FOREIGN KEY(emp_no) REFERENCES employees(emp_no) ON DELETE CASCADE"
    ");")

DB_NAME = "/Users/dev-yoshiki/Hobby/sleepy/src/primely/primely.sqlite"


class SQLiteModel(object):

    def __init__(self, memory=False, cnx=None, cur=None):
        if memory:
            self.db_name = ':memory:'
            print('##### SQLite is ran on memory #####')
        else:
            self.db_name = DB_NAME
        self.cnx = cnx
        self.cur = cur
        self.__connect_db()

    def __connect_db(self):
        self.cnx = sqlite3.connect(self.db_name)
        self.cur = self.cnx.cursor()

    # def check_database_existance(self):
    #     try:
    #         self.cur.execute(f"USE {DB_NAME}")
    #     except:
    #         print(f"Database {DB_NAME} does not exists.")
    #         self.create_database()

    # def create_database(self):
    #     try:
    #         self.cur.execute(
    #             f"CREATE DATABASE {DB_NAME} DEFAULT CHARACTER SET 'utf8'")
    #     except:
    #         print("Failed creating database: ")
    #         exit(1)

    def create_table(self):
        for table_name in TABLES:
            table_description = TABLES[table_name]
            try:
                print(f"Creating table {table_name}: ", end='')
                self.cur.execute(table_description)
            except sqlite3.OperationalError as err:
                print(f'{err}')
            else:
                print("OK")

    def commit(self):
        self.cnx.commit()

    def __close(self):
        self.cnx.close()

    def __del__(self):
        self.__close()


class PrimelySQLiteModel(SQLiteModel):
    def __init__(self, memory):
        super().__init__(memory)

    def execute_data(self, query=None, insert=None):
        """SELECT, INSERT"""
        # print('insert:', insert)
        print('Executing data: ', end='')
        try:
            if not insert:
                self.cur.execute(query)
            elif type(insert) is tuple:
                self.cur.execute(query, insert)
            elif type(insert) is list:
                self.cur.executemany(query, insert)
        except sqlite3.IntegrityError as err:
            # print(f'{__name__} failed')
            print(f'{err}')
            # print('Record alrealy exist:', err)
        else:
            print('success')

    def select_data(self, category):

        select_value_int = (
            "SELECT paid_date, cat_name, value_int FROM value_by_types "
            "WHERE cat_type=? "
            "ORDER BY paid_date ASC")

        select_value_flt = (
            "SELECT paid_date, cat_name, value_flt FROM value_by_types "
            "WHERE cat_type=? "
            "ORDER BY paid_date ASC")

        select_value_str = (
            "SELECT paid_date, cat_name, value_str FROM value_by_types "
            "WHERE cat_type=? "
            "ORDER BY paid_date ASC")

        if category in ['incomes', 'deductions']:
            query = select_value_int
            value_col = 'value_int'
        elif category in ['attendances']:
            query = select_value_flt
            value_col = 'value_flt'

        p = (category,)

        # print('para:', p)
        df = pd.read_sql_query(sql=query, con=self.cnx, params=p)
        return df

def test_sqlite():

    category = 'incomes'
    # category = 'deductions'
    # category = 'attendances'

    sqlite_model = PrimelySQLiteModel(memory=False)
    # for category in ['incomes', 'deductions', 'attendances']:
    if category in ['incomes', 'deductions']:
        value_type = 'value_int'
    elif category in ['attendances']:
        value_type = 'value_flt'

    df = sqlite_model.select_data(category)
    # print(df)
    table = pd.pivot_table(df, index='cat_name', columns='paid_date', values=value_type, fill_value=0)
    print(table)

    response = {'incomes': {}, 'deductions': {}, 'attendances': {}}

    v_array = table.values
    rows    = {'rows': list(table.index)}
    columns = {'columns': list(table.columns)}
    values  = {'values': v_array.tolist()}

    response[category].update(rows)
    response[category].update(columns)
    response[category].update(values)

    print(response)



if __name__ == "__main__":
    test_sqlite()
