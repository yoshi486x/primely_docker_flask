import os
import pandas as pd
import pathlib
import sqlite3

try:
    from models import visualizing, db, files
except:
    from primely.models import visualizing, db, files


class PaycheckDataInjector(object):

    JSON_PATH = 'data/tmp/json/'
    INSERT_EMPLOYEES = \
        "INSERT INTO employees (emp_no, emp_name) "\
        "VALUES (?, ?)"
    INSERT_VALUE_BY_TYPE = \
        "INSERT INTO value_by_types "\
        "(emp_no, paid_date, cat_name, cat_type, value_int, value_flt, value_str) "\
        "VALUES (?, ?, ?, ?, ?, ?, ?)"

    def __init__(self, memory=False):
        self.sqlite_model = db.PrimelySQLiteModel(memory)
        self.sqlite_model.create_table()
        self.walkthrough_db_inserts()

    def walkthrough_db_inserts(self):
        filenames = os.listdir(self.JSON_PATH)
        filenames.sort()

        for filename in filenames:
            json_loader = visualizing.JsonLoaderModel(filename, self.JSON_PATH)
            # print(json_loader.dict_data)
            try:
                self.execute_employees_values(json_loader.dict_data)
            except sqlite3.IntegrityError as err:
                print(f'{err}')
            self.execute_value_by_types(json_loader.dict_data)

    def execute_employees_values(self, paycheck):
        emp_no = paycheck['emp_no']
        emp_name = paycheck['emp_name']
        self.sqlite_model.execute_data(self.INSERT_EMPLOYEES, (emp_no, emp_name))
        self.sqlite_model.commit()

    def execute_value_by_types(self, paycheck):
        emp_no = paycheck['emp_no']
        paid_date = paycheck['paid_date']
        cat_type_list = ['incomes', 'deductions', 'attendances']
        record_list = []

        for cat_type in cat_type_list:
            # cat_name, cat_value = paycheck[cat_type].items()
            for cat_name, cat_value in paycheck[cat_type].items():

                values = {
                    'value_int': None,
                    'value_flt': None,
                    'value_str': None}
                if type(cat_value) is int:
                    values['value_int'] = cat_value
                elif type(cat_value) is float:
                    values['value_flt'] = cat_value
                else:
                    values['value_str'] = cat_value
                record = (emp_no, paid_date, cat_name, cat_type, 
                    values['value_int'], values['value_flt'], values['value_str'])
                record_list.append(record)

        self.sqlite_model.execute_data(self.INSERT_VALUE_BY_TYPE, record_list)
        self.sqlite_model.commit()


class DatabaseSelector(object):

    TIMECHART = {'incomes': {}, 'deductions': {}, 'attendances': {}}

    def __init__(self, param, response=TIMECHART):
        self.param = param
        self.response = response

    def select_response(self):
        if self.param == 'all':
            for category in ['incomes', 'deductions', 'attendances']:
                self._create_table(category)
        else:
            self._create_table(self.param)

    def _create_table(self, category):
        sqlite_model = db.PrimelySQLiteModel(memory=False)
        df = sqlite_model.select_data(category)
        # print(df)
        if category in ['incomes', 'deductions']:
            value_type = 'value_int'
        elif category in ['attendances']:
            value_type = 'value_flt'
        table = pd.pivot_table(df, index='cat_name', columns='paid_date', values=value_type, fill_value=0)
        # print(table)
        self._update_category(table, category)

    def _update_category(self, table, category):
        v_array = table.values
        rows    = {'rows': list(table.index)}
        columns = {'columns': list(table.columns)}
        values  = {'values': v_array.tolist()}

        self.response[category].update(rows)
        self.response[category].update(columns)
        self.response[category].update(values)

    def get_response(self):
        return self.response
    
    def __del__(self):
        print(f'Extracted {self.response}')



if __name__ == "__main__":
    # PaycheckDataInjector(True)
    db_selector = DatabaseSelector(param='incomes')
    db_selector.select_response()
    response = db_selector.get_response()
    print(response)