import os
import pathlib


def setup_output_dir(output_dir):

    if not os.path.exists(output_dir):
        pathlib.Path(output_dir).mkdir(parents=True)
    else:
        print('Designated directory `{}` already exists.'.format(output_dir))    