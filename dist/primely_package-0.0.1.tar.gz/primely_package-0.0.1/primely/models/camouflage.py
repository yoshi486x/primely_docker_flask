"""Can't show my income on internet! Camouflage it with this script"""
import numpy as np
import pandas as pd

def camouflage(df):
    """Camouflage actual paycheck values"""
    df = df.applymap(multiply_income)
    # print('this is camouflage')
    # print(df)

    return df

def multiply_income(base):

    if base < 0:
        base = abs(base)
    elif base < 10000 and base > 5000:
        base = base * 12
    multiplied = base * 6

    return multiplied

